//
//  PostViewController.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 21/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "PostViewController.h"

@interface PostViewController ()

@end

@implementation PostViewController

@synthesize TextPOST;
@synthesize TextPOSTResponse;
@synthesize TextPOSTGender;
@synthesize TextPOSTRealName;
@synthesize TextPOSTPublisher;

NSString *dataString;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ButtonPost:(id)sender {
    
    NSString *TextName = TextPOST.text;
    NSString *TextNameGender = TextPOSTGender.text;
    NSString *TextNameRealName = TextPOSTRealName.text;
    NSString *TextNamePublisher = TextPOSTPublisher.text;
    
    if ([TextName length] == 0 || [TextNameGender length] == 0 || [TextNameRealName length] == 0 || [TextNamePublisher length] == 0)
    {
        [self alertView];
    }
    else
    {
        NSString *TextNamePublisherInt;
        if([TextNamePublisher isEqualToString:@"Marvel Comics"]) {TextNamePublisherInt = @"1";}
        if([TextNamePublisher isEqualToString:@"DC Comics"]) {TextNamePublisherInt = @"2";}
        
    NSString *post =[NSString stringWithFormat:@"username=casalazar@gmail.com&Password=jcawypjd"];
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSString *postLength = [NSString stringWithFormat:@"%lu",(unsigned long)[postData length]];
    
    // Create the URLSession on the default configuration
    NSURLSessionConfiguration *defaultSessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration:defaultSessionConfiguration];
    
    // Setup the request with URL
    NSURL *url = [NSURL URLWithString:@"https://afternoon-river-50291.herokuapp.com/superheroe/"];
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url];
    
    // Convert POST string parameters to data using UTF8 Encoding
    NSString *postParams = [NSString stringWithFormat: @"name=%@&gender=%@&real_name=%@&publisher=%@", TextName, TextNameGender, TextNameRealName, TextNamePublisherInt];
    NSData *Params = [postParams dataUsingEncoding:NSUTF8StringEncoding];
        
        NSLog(@"Parámetros _____ %@", postParams);
    
    // Convert POST string parameters to data using UTF8 Encoding
    [urlRequest setURL:url];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [urlRequest setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [urlRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [urlRequest setHTTPBody:Params];
        
    // Create dataTask
    NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
        int statusCodeInt = (int)[httpResponse statusCode];
        
        if (statusCodeInt < 350)
        {
            [self Exitosa];
            NSLog(@"RESPONSE _____ %@", response);
            NSLog(@"ERROR _____ %@", error);
        }
        else
        {
            [self Defectuosa];
            NSLog(@"RESPONSE _____ %@", response);
            NSLog(@"ERROR _____ %@", error);
        }

        // Handle your response here
    }];
    
    // Fire the request
    [dataTask resume];
    }
}

-(void)Exitosa
{
    [TextPOSTResponse performSelectorOnMainThread:@selector(setText:) withObject:@"CONEXIÓN EXITOSA" waitUntilDone:NO];
}

-(void)Defectuosa
{
    [TextPOSTResponse performSelectorOnMainThread:@selector(setText:) withObject:@"CONEXIÓN DEFECTUOSA" waitUntilDone:NO];
}

- (void)alertView{
    
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"Title"
                                                                    message:@"Message"
                                                             preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Yes, please"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
    {
        /** What we write here???????? **/
        NSLog(@"you pressed Yes, please button");
        
        // call method whatever u need
    }];
    
    UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"No, thanks"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action)
    {
        /** What we write here???????? **/
        NSLog(@"you pressed No, thanks button");
        // call method whatever u need
    }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (IBAction)TDTextName:(id)sender {
    TextPOST.text = @"";
}

- (IBAction)TDTextGender:(id)sender {
    TextPOSTGender.text = @"";
}

- (IBAction)TDRealName:(id)sender {
    TextPOSTRealName.text = @"";
}

- (IBAction)TDPublisher:(id)sender {
    TextPOSTPublisher.text = @"";
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
