//
//  FSCalendarViewController.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 23/05/18.
//  Copyright © 2018 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSCalendarViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *FechaSeleccionada;


@end
