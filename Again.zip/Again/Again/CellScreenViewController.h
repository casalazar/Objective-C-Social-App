//
//  CellScreenViewController.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 16/10/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellScreenViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *EmailCell;
@property (weak, nonatomic) IBOutlet UILabel *IDLabel;
@property (weak, nonatomic) IBOutlet UIImageView *ImageCell;

@property (strong, nonatomic) NSString *EmailCellString;
@property (strong, nonatomic) NSString *IDCellString;
@property (strong, nonatomic) NSString *URLImageCellString;

@end
