//
//  TableViewHTTPViewController.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 3/10/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewHTTPViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>

@property (weak, nonatomic) IBOutlet UITableView *HTTPTableView;

@property (nonatomic, strong) NSMutableArray *searchResultsHTTP;
@property (nonatomic, strong) UISearchBar *searchBarHTTP;

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchTextHTTP;

@end
