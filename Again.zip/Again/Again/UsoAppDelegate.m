//
//  UsoAppDelegate.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 21/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "UsoAppDelegate.h"
#import "AppDelegate.h"

@interface UsoAppDelegate ()

@end

@implementation UsoAppDelegate

@synthesize ButtonUseAppDelegate;
@synthesize TextViewJson;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)UsoAppDelegate:(id)sender {
    AppDelegate *Delegate =  (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [Delegate CallJson];
    //[Delegate CallQueryJson];
    
    [NSThread sleepForTimeInterval:2.0f];
    
    AppDelegate *JsonDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    TextViewJson.text = [NSString stringWithFormat:@"%@", JsonDelegate.JsonString];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
