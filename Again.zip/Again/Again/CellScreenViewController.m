//
//  CellScreenViewController.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 16/10/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "CellScreenViewController.h"
#import "TableViewHTTPViewController.h"

@interface CellScreenViewController ()

@end

@implementation CellScreenViewController

@synthesize EmailCell;
@synthesize IDLabel;
@synthesize ImageCell;
@synthesize EmailCellString;
@synthesize IDCellString;
@synthesize URLImageCellString;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"%@", EmailCellString);
    EmailCell.text = EmailCellString;
    IDLabel.text = IDCellString;
    
    self.ImageCell.layer.cornerRadius = ImageCell.frame.size.height /2;
    self.ImageCell.layer.masksToBounds = YES;
    self.ImageCell.layer.borderWidth = 0;
    
    NSURL *imageUrlcell =[NSURL URLWithString:URLImageCellString];
    NSData *imageDatacell = [[NSData alloc] initWithContentsOfURL:imageUrlcell];
    ImageCell.image = [UIImage imageWithData:imageDatacell];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
