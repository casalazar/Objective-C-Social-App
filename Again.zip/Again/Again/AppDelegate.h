//
//  AppDelegate.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 21/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, assign) NSString *JsonString;
@property (nonatomic, assign) NSMutableDictionary *JsonDic;

@property (nonatomic, assign) NSString *QNameJsonString;
@property (nonatomic, assign) NSString *QEmailJsonString;
@property (nonatomic, assign) NSString *QImageJsonString;
@property (nonatomic, assign) NSString *QIDJsonString;

-(void)CallJson;
-(void)CallQueryJson;

@end

