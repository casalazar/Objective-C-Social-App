//
//  TableViewController.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 27/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "TableViewController.h"
#import "TableViewCell.h"

@interface TableViewController ()

@end

@implementation TableViewController
{
    NSMutableArray *tableData;
    NSMutableArray *tableImage;
 
    BOOL isSearching;
}

@synthesize ExTableViewController;
@synthesize searchResults;
@synthesize searchBar;
static const CGFloat topOffset = 20; // use 20 if there's no navigation bar, or zero if there's no status bar either
NSString *infoSelect;
NSIndexPath *indexDeselect;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // Initialize table data
    tableData = [NSMutableArray arrayWithObjects:@"Egg Benedict", @"Mushroom Risotto", @"Full Breakfast", @"Hamburger", @"Ham and Egg Sandwich", @"Creme Brelee", @"White Chocolate Donut", @"Starbucks Coffee", @"Vegetable Curry", @"Instant Noodle with Egg", @"Noodle with BBQ Pork", @"Japanese Noodle with Pork", @"Green Tea", @"Thai Shrimp Cake", @"Angry Birds Cake", @"Ham and Cheese Panini", nil];
    tableImage = [NSMutableArray arrayWithObjects:@"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", @"boyFichaje.png", nil];
    
    //CGFloat height = self.view.frame.size.height;
    CGFloat width  = self.view.frame.size.width;
    
    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, topOffset, width, 40)];
    searchBar.delegate = self;
    [self.view addSubview:self.searchBar];
    
    self.ExTableViewController.contentInset = UIEdgeInsetsMake(self.searchBar.frame.size.height, 0, 0, 0);
    self.ExTableViewController.scrollIndicatorInsets = UIEdgeInsetsMake(self.searchBar.frame.size.height, 0, 0, 0);
    
    self.searchResults = [NSMutableArray arrayWithCapacity:[tableData count]];

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (isSearching) {
        return [searchResults count];
    } else {
        return [tableData count];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"TableViewCell";
    
    TableViewCell *cell = (TableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    if (isSearching) {
    cell.CellLabel1.text = [self.searchResults objectAtIndex:indexPath.row];
    cell.CellImageTableView.image = [UIImage imageNamed:[tableImage objectAtIndex:indexPath.row]];
    } else {
    cell.CellLabel1.text = [tableData objectAtIndex:indexPath.row];
    cell.CellImageTableView.image = [UIImage imageNamed:[tableImage objectAtIndex:indexPath.row]];
    }
    
    return cell;
}

#pragma mark - Search delegate methods

- (void)filterContentForSearchText:(NSString*)searchText
{
    [self.searchResults removeAllObjects];
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"SELF CONTAINS %@",
                                    searchText];
    
    self.searchResults = [NSMutableArray arrayWithArray: [tableData filteredArrayUsingPredicate:resultPredicate]];
    [ExTableViewController reloadData];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchBar.text.length == 0) {
        isSearching = NO;
        [self.ExTableViewController reloadData];
        
         NSLog(@"%@",searchText);
    }
    else {
        isSearching = YES;
        [self filterContentForSearchText:searchBar.text];
    }
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    isSearching = YES;
    [self filterContentForSearchText:searchBar.text];
}

-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    [searchBar setText:@""];
    isSearching = NO;
    [ExTableViewController reloadData];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    indexDeselect = indexPath;
    infoSelect = [tableData objectAtIndex:indexPath.row];
    [self alertView];
    
    UITableViewCell *cell = [ExTableViewController cellForRowAtIndexPath:indexDeselect];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
}

- (void)alertView{
    
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"Row Select"
                                                                    message:infoSelect
                                                             preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Yes, please"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
                                {
                                    /** What we write here???????? **/
                                    NSLog(@"you pressed Yes, please button");
                                    // call method whatever u need
                                }];
    
    UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"No, thanks"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action)
                               {
                                   /** What we write here???????? **/
                                   NSLog(@"you pressed No, thanks button");
                                   [ExTableViewController deselectRowAtIndexPath:indexDeselect animated:YES];
                                   
                                   UITableViewCell *cell = [ExTableViewController cellForRowAtIndexPath:indexDeselect];
                                   cell.accessoryType = UITableViewCellAccessoryNone;
                                   // call method whatever u need
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
}

/*
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGRect frame = self.searchBar.frame;
    frame.origin.y = scrollView.contentOffset.y + topOffset;
    self.searchBar.frame = frame;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
