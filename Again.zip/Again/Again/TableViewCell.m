//
//  TableViewCell.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 27/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

@synthesize CellImageTableView = _CellImageTableView;
@synthesize CellLabel1 = _CellLabel1;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    _CellImageTableView.layer.cornerRadius = _CellImageTableView.frame.size.height /2;
    _CellImageTableView.layer.masksToBounds = YES;
    _CellImageTableView.layer.borderWidth = 0;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
