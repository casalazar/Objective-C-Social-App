//
//  TableViewController.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 27/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>

@property (weak, nonatomic) IBOutlet UITableView *ExTableViewController;

@property (nonatomic, strong) NSMutableArray *searchResults;

@property (nonatomic, strong) UISearchBar *searchBar;

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText; 

@end
