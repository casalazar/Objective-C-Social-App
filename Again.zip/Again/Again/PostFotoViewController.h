//
//  PostFotoViewController.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 23/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostFotoViewController : UIViewController <UINavigationControllerDelegate,
UIImagePickerControllerDelegate>


@property (weak, nonatomic) IBOutlet UIImageView *PostImageView;
@property (weak, nonatomic) IBOutlet UIButton *FotoSelec;

@property (weak, nonatomic) IBOutlet UITextField *SupernameTxt;
@property (weak, nonatomic) IBOutlet UITextField *SuperGenTxt;
@property (weak, nonatomic) IBOutlet UITextField *SuperRealNameTxt;
@property (weak, nonatomic) IBOutlet UITextField *SuperEdiTxt;

@property (weak, nonatomic) IBOutlet UILabel *ConexionState;

@end
