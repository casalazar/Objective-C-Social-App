//
//  PostViewController.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 21/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *TextPOST;
@property (weak, nonatomic) IBOutlet UITextView *TextPOSTResponse;
@property (weak, nonatomic) IBOutlet UITextField *TextPOSTGender;
@property (weak, nonatomic) IBOutlet UITextField *TextPOSTRealName;
@property (weak, nonatomic) IBOutlet UITextField *TextPOSTPublisher;


@end
