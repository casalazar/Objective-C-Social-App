//
//  PostFotoViewController.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 23/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "PostFotoViewController.h"

@interface PostFotoViewController ()

@end

@implementation PostFotoViewController

@synthesize PostImageView;
@synthesize SupernameTxt;
@synthesize SuperGenTxt;
@synthesize SuperRealNameTxt;
@synthesize SuperEdiTxt;
@synthesize ConexionState;

NSString *NameString;
NSString *GenderString;
NSString *RealNameString;
NSString *PublisherString;
NSString *PublisherNum;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.PostImageView.layer.cornerRadius = PostImageView.frame.size.height /2;
    self.PostImageView.layer.masksToBounds = YES;
    self.PostImageView.layer.borderWidth = 0;
}

-(void)viewDidAppear:(BOOL)animated
{
        ConexionState.text = @"";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ButtonPostFoto:(id)sender {
    
    ConexionState.text = @"";
    
    if ([SupernameTxt.text length] == 0 || [SuperGenTxt.text length] == 0 || [SuperRealNameTxt.text length] == 0 || [SuperEdiTxt.text length] == 0)
    {
        [self alertView];
    }
    else
    {
    
    NameString = SupernameTxt.text;
    GenderString = SuperGenTxt.text;
    RealNameString = SuperRealNameTxt.text;
    
    PublisherString = SuperEdiTxt.text;
    
    if([PublisherString isEqualToString:@"Marvel Comics"]) {PublisherNum = @"1";}
    if([PublisherString isEqualToString:@"DC Comics"]) {PublisherNum = @"2";}
    
    NSString *imageName = [NSString stringWithFormat:@"%@.png", NameString];
        
        UIImage * image = PostImageView.image;
        CGSize sacleSize = CGSizeMake(10, 10);
        UIGraphicsBeginImageContextWithOptions(sacleSize, NO, 0.0);
        [image drawInRect:CGRectMake(0, 0, sacleSize.width, sacleSize.height)];
        UIImage * resizedImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
    NSData *imageData = UIImagePNGRepresentation(resizedImage);
    
    NSDictionary *postParams = @{@"name" : NameString, @"gender" : GenderString, @"real_name" : RealNameString, @"publisher" : PublisherNum};
    
    NSURL *urlString = [NSURL URLWithString:@"https://afternoon-river-50291.herokuapp.com/superheroe/"];
    NSMutableURLRequest *request= [[NSMutableURLRequest alloc] initWithURL:urlString];
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration];
    
    [request setURL:urlString];
    [request setHTTPMethod:@"POST"];
    
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    NSMutableData *body = [NSMutableData data];
    
    NSString *postData = [self getHTTPBodyParamsFromDictionary:postParams boundary:boundary];
    [body appendData:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    [body appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"image\"; filename=\"%@\"\r\n", imageName] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Type: image/png\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[NSData dataWithData:imageData]];
    
    [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPBody:body];

    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
        int statusCodeInt = (int)[httpResponse statusCode];
        
        if (statusCodeInt < 350)
        {
            [self Exitosa];
            NSLog(@"RESPONSE _____ %@", response);
            //NSLog(@"ERROR _____ %@", error);
        }
        else
        {
            [self Defectuosa];
            //NSLog(@"RESPONSE _____ %@", response);
            NSLog(@"ERROR _____ %@", error);
        }

    }];
    
    [postDataTask resume];
    }
}

-(void)Exitosa
{
    dispatch_async(dispatch_get_main_queue(), ^{
        ConexionState.text = @"Conexión exitosa";
        [ConexionState setNeedsDisplay];
    });
}

-(void)Defectuosa
{
    dispatch_async(dispatch_get_main_queue(), ^{
        ConexionState.text = @"Fallo en la conexión";
        [ConexionState setNeedsDisplay];
    });
}

-(NSString *) getHTTPBodyParamsFromDictionary: (NSDictionary *)params boundary:(NSString *)boundary
{
    NSMutableString *tempVal = [[NSMutableString alloc] init];
    for(NSString * key in params)
    {
        [tempVal appendFormat:@"\r\n--%@\r\n", boundary];
        [tempVal appendFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n%@",key,[params objectForKey:key]];
    }
    return [tempVal description];
}


- (IBAction)ButtoSelecImage:(id)sender {
    UIImagePickerController *pickerViewController = [[UIImagePickerController alloc] init];
    pickerViewController.allowsEditing = YES;
    pickerViewController.delegate = self;
    [pickerViewController setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [self presentViewController:pickerViewController animated:YES completion:nil];
}

- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [self dismissViewControllerAnimated:picker completion:nil];
    UIImage *imagetake = [info valueForKey:UIImagePickerControllerEditedImage];
    PostImageView.image = imagetake;
}

- (IBAction)NameEmptyDown:(id)sender {
    SupernameTxt.text = @"";
}
- (IBAction)GenderEmptyDown:(id)sender {
    SuperGenTxt.text = @"";
}

- (IBAction)RealNameEmptyDown:(id)sender {
    SuperRealNameTxt.text = @"";
}

- (IBAction)PublisherEmpty:(id)sender {
    SuperEdiTxt.text = @"";
}

- (void)alertView{
    
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"Title"
                                                                    message:@"Message"
                                                             preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Yes, please"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
                                {
                                    /** What we write here???????? **/
                                    NSLog(@"you pressed Yes, please button");
                                    
                                    // call method whatever u need
                                }];
    
    UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"No, thanks"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action)
                               {
                                   /** What we write here???????? **/
                                   NSLog(@"you pressed No, thanks button");
                                   // call method whatever u need
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
