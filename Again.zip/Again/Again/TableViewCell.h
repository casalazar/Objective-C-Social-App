//
//  TableViewCell.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 27/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *CellImageTableView;
@property (weak, nonatomic) IBOutlet UILabel *CellLabel1;

@end
