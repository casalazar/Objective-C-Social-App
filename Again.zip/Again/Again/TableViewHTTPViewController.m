//
//  TableViewHTTPViewController.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 3/10/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "TableViewHTTPViewController.h"
#import "TableViewCell.h"
#import "AppDelegate.h"
#import "CellScreenViewController.h"


@interface TableViewHTTPViewController ()

@end

@implementation TableViewHTTPViewController
{
    NSMutableArray *tableIDHTTP;
    NSMutableArray *tableDataHTTP;
    NSMutableArray *tableImageHTTP;
    
    NSArray *QIDArrayRespond;
    NSArray *QNameArrayRespond;
    NSArray *QImageArrayRespond;
    
    BOOL isSearching;
} 

@synthesize HTTPTableView;
@synthesize searchResultsHTTP;
@synthesize searchBarHTTP;

static const CGFloat topOffsetHTTP = 20; // use 20 if there's no navigation bar, or zero if there's no status bar either
NSString *infoSelectHTTP;
NSIndexPath *indexDeselectHTTP;

NSString *QIDStringRespond;
NSString *QNameStringRespond;
NSString *QEmailStringRespond;
NSString *QImageStringRespond;
NSString *NameCellStringPass;
NSString *IDCellStringPass;
NSString *URLImageCellStringPass;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // Initialize table data
    AppDelegate *DelegateQuery =  (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [DelegateQuery CallQueryJson];
    
    [NSThread sleepForTimeInterval:2.0f];
    
    AppDelegate *JsonDelegateQuery = (AppDelegate *)[UIApplication sharedApplication].delegate;
    //TextViewJson.text = [NSString stringWithFormat:@"%@", JsonDelegateQuery.JsonString];
    QIDStringRespond = [NSString stringWithFormat:@"%@", JsonDelegateQuery.QIDJsonString];
    QNameStringRespond = [NSString stringWithFormat:@"%@", JsonDelegateQuery.QNameJsonString];
    QEmailStringRespond = [NSString stringWithFormat:@"%@", JsonDelegateQuery.QEmailJsonString];
    QImageStringRespond = [NSString stringWithFormat:@"%@", JsonDelegateQuery.QImageJsonString];
        NSLog(@"%@",QIDStringRespond);
        NSLog(@"%@",QNameStringRespond);
        NSLog(@"%@",QEmailStringRespond);
        NSLog(@"%@",QImageStringRespond);
    
    QIDArrayRespond = [QIDStringRespond componentsSeparatedByString:@","];
    tableIDHTTP = [[NSMutableArray alloc]initWithArray:QIDArrayRespond];

    QNameArrayRespond = [QNameStringRespond componentsSeparatedByString:@","];
    tableDataHTTP = [[NSMutableArray alloc]initWithArray:QNameArrayRespond];
    
    QImageArrayRespond = [QImageStringRespond componentsSeparatedByString:@","];
    tableImageHTTP = [[NSMutableArray alloc]initWithArray:QImageArrayRespond];
    
    //CGFloat height = self.view.frame.size.height;
    CGFloat width  = self.view.frame.size.width;
    
    self.searchBarHTTP = [[UISearchBar alloc] initWithFrame:CGRectMake(0, topOffsetHTTP, width, 40)];
    searchBarHTTP.delegate = self;
    [self.view addSubview:self.searchBarHTTP];
    
    self.HTTPTableView.contentInset = UIEdgeInsetsMake(self.searchBarHTTP.frame.size.height, 0, 0, 0);
    self.HTTPTableView.scrollIndicatorInsets = UIEdgeInsetsMake(self.searchBarHTTP.frame.size.height, 0, 0, 0);
    
    self.searchResultsHTTP = [NSMutableArray arrayWithCapacity:[tableDataHTTP count]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (isSearching) {
        return [searchResultsHTTP count];
    } else {
        return [tableDataHTTP count];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"TableViewCell";
    
    TableViewCell *cell = (TableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    if (isSearching) {
        cell.CellLabel1.text = [self.searchResultsHTTP objectAtIndex:indexPath.row];
        NSURL *imageUrl =[NSURL URLWithString:[tableImageHTTP objectAtIndex:indexPath.row]];
        NSData *imageData = [[NSData alloc] initWithContentsOfURL:imageUrl];
        cell.CellImageTableView.image = [UIImage imageWithData:imageData];
    } else {
        cell.CellLabel1.text = [tableDataHTTP objectAtIndex:indexPath.row];
        NSURL *imageUrl =[NSURL URLWithString:[tableImageHTTP objectAtIndex:indexPath.row]];
        NSData *imageData = [[NSData alloc] initWithContentsOfURL:imageUrl];
        cell.CellImageTableView.image = [UIImage imageWithData:imageData];
    }
    
    return cell;
}

#pragma mark - Search delegate methods

- (void)filterContentForSearchText:(NSString*)searchText
{
    [self.searchResultsHTTP removeAllObjects];
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"SELF CONTAINS %@",
                                    searchText];
    
    self.searchResultsHTTP = [NSMutableArray arrayWithArray: [tableDataHTTP filteredArrayUsingPredicate:resultPredicate]];
    [HTTPTableView reloadData];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchBar.text.length == 0) {
        isSearching = NO;
        [self.HTTPTableView reloadData];
        
        NSLog(@"%@",searchText);
    }
    else {
        isSearching = YES;
        [self filterContentForSearchText:searchBar.text];
    }
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    isSearching = YES;
    [self filterContentForSearchText:searchBar.text];
}

-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    [searchBar setText:@""];
    isSearching = NO;
    [HTTPTableView reloadData];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    indexDeselectHTTP = indexPath;
    infoSelectHTTP = [tableDataHTTP objectAtIndex:indexPath.row];
    IDCellStringPass = [tableIDHTTP objectAtIndex:indexPath.row];
    NameCellStringPass = [tableDataHTTP objectAtIndex:indexPath.row];
    URLImageCellStringPass = [tableImageHTTP objectAtIndex:indexPath.row];
    [self alertView];
    
    UITableViewCell *cell = [HTTPTableView cellForRowAtIndexPath:indexDeselectHTTP];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
}

- (void)alertView{
    
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"Row Select"
                                                                    message:infoSelectHTTP
                                                             preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"Yes, please"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action)
                                {
                                    /** What we write here???????? **/
                                    NSLog(@"%@, %@, %@", NameCellStringPass, IDCellStringPass, URLImageCellStringPass);
                                    
                                    [self performSegueWithIdentifier:@"GoInfoCell" sender:self];
                                    
                                    /*
                                    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                    UIViewController *feedbackVC = [storyboard   instantiateViewControllerWithIdentifier:@"CellInfoViewController"] ;
                                    [self presentViewController:feedbackVC animated:YES completion:nil];
                                    */
                                    // call method whatever u need
                                }];
    
    UIAlertAction* noButton = [UIAlertAction actionWithTitle:@"No, thanks"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action)
                               {
                                   /** What we write here???????? **/
                                   NSLog(@"you pressed No, thanks button");
                                   [HTTPTableView deselectRowAtIndexPath:indexDeselectHTTP animated:YES];
                                   
                                   UITableViewCell *cell = [HTTPTableView cellForRowAtIndexPath:indexDeselectHTTP];
                                   cell.accessoryType = UITableViewCellAccessoryNone;
                                   // call method whatever u need
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"GoInfoCell"]) {
        //NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        CellScreenViewController *destViewController = segue.destinationViewController;
        destViewController.EmailCellString = NameCellStringPass;
        destViewController.IDCellString = IDCellStringPass;
        destViewController.URLImageCellString = URLImageCellStringPass;
    }
}

@end
