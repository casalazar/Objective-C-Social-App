//
//  ViewController.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 21/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *Text1ViewController;

@property (weak, nonatomic) IBOutlet UIButton *Button1ViewController;

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender;

@property (nonatomic, assign) NSString *TextPas1;

@end

