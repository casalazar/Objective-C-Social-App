//
//  FirstViewController.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 21/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *Text1FirstViewController;

@property (weak, nonatomic) IBOutlet UIButton *Buttton1FirstViewController;

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender;

@property (nonatomic, assign) NSString *TextPas2;

@end
