//
//  UsoAppDelegate.h
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 21/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UsoAppDelegate : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *ButtonUseAppDelegate;
@property (weak, nonatomic) IBOutlet UITextView *TextViewJson;


@end
