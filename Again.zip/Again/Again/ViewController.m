//
//  ViewController.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 21/09/17.
//  Copyright © 2017 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "ViewController.h"
#import "FirstViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize Text1ViewController;
@synthesize Button1ViewController;
@synthesize TextPas1;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    Text1ViewController.text = TextPas1;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)Button1DownAction:(id)sender {
    TextPas1 = Text1ViewController.text;
        [self performSegueWithIdentifier:@"Segue1" sender:sender];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"Segue1"]){
        FirstViewController *controller = (FirstViewController *)segue.destinationViewController;
        controller.TextPas2 = TextPas1;
    }
}

@end
