//
//  FSCalendarViewController.m
//  Again
//
//  Created by Carlos Andres Salazar Martinez on 23/05/18.
//  Copyright © 2018 Carlos Andres Salazar Martinez. All rights reserved.
//

#import "FSCalendarViewController.h"
#import <EventKit/EventKit.h>

@interface FSCalendarViewController ()

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *calendarHeightConstraint;

@property (strong, nonatomic) NSDateFormatter *formatter;

@end


@implementation FSCalendarViewController

@synthesize FechaSeleccionada;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.formatter = [[NSDateFormatter alloc] init];
    self.formatter.dateFormat = @"yyyy/MM/dd";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)calendar:(FSCalendarViewController *)calendar didSelectDate:(NSDate *)date 
{
    NSLog(@"did select date %@",[self.formatter stringFromDate:date]);
    NSString *string = [self.formatter stringFromDate:date];
    FechaSeleccionada.text = string;
}

- (void)calendar:(FSCalendarViewController *)calendar boundingRectWillChange:(CGRect)bounds animated:(BOOL)animated
{
    self.calendarHeightConstraint.constant = CGRectGetHeight(bounds);
    // Do other updates here
    [self.view layoutIfNeeded];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
